
-- =============================================
-- Objeto:	[V_ESTRATEGIA_CLIENTE_COTA]
-- Descri��o:	<View que lista o rendimento da cota da carteira>
-- Depend�ncias:	Depende de ->	dbo.PROX_DIA_UTIL, dbo.TruncaFormata, dbo.ESTRATEGIA
--									dbo.ESTRATEGIA_CLIENTE_ASSOCIADO, dbo.Indicadores_Financeiros
--									dbo.ESTRATEGIA_CLIENTE_COTA_RENT,	dbo.Cliente
--					Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'V_ESTRATEGIA_CLIENTE_COTA') 
begin
	exec('DROP VIEW [dbo].[V_ESTRATEGIA_CLIENTE_COTA]')
end

GO

CREATE VIEW [dbo].[V_ESTRATEGIA_CLIENTE_COTA]
AS
SELECT        DIA_ATUAL.DT_MVTO, DIA_ATUAL.CD_BVSP, dbo.Cliente.nome_cliente AS NOME_CLIENTE, ESTRATEGIA.NR_ESTRATEGIA AS NR_ESTRATEGIA, ESTRATEGIA.NM_ABREV_ESTRATEGIA AS NM_ABREV, ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA, 
                         DIA_ATUAL.VL_PL_ANTERIOR, DIA_ATUAL.VL_PL_DIA, DIA_ATUAL.VL_COTA_TAXA AS COTA_DIA, DIA_ATUAL.VL_RENT_TAXA AS RENT_DIA, ISNULL(MES_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_MES_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_MES, ISNULL(ANO_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_ANO_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(ANO_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_ANO, ISNULL(MES_03_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_MES_03_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_03_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_03, ISNULL(MES_06_ANT.VL_COTA_TAXA, COTA_INICIAL) 
                         AS COTA_MES_06_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_06_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_06, ISNULL(MES_12_ANT.VL_COTA_TAXA, 
                         COTA_INICIAL) AS COTA_MES_12_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_12_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_12, ISNULL(COTA_INICIAL, 1) 
                         AS COTA_INICIO, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(COTA_INICIAL, 1) - 1) * 100, 6, N'T') AS RENT_INICIO
FROM            dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS DIA_ATUAL INNER JOIN
                         dbo.ESTRATEGIA ON 1 = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                         ESTRATEGIA_CLIENTE_ASSOCIADO ON ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP = CASE WHEN ISNULL(ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP, 0) <> 0 THEN DIA_ATUAL.CD_BVSP ELSE 0 END AND 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.NR_ESTRATEGIA = 1 AND ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA <= DIA_ATUAL.DT_MVTO INNER JOIN
                         dbo.Cliente ON DIA_ATUAL.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + '/' + CAST(MONTH(DIA_ATUAL.DT_MVTO) AS CHAR) + '/' + CAST('01' AS CHAR) 
                         AS SMALLDATETIME), - 1) = MES_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS ANO_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + CAST('/01/01' AS CHAR) AS SMALLDATETIME), - 1) = ANO_ANT.DT_MVTO AND 
                         DIA_ATUAL.CD_BVSP = ANO_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_03_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 2, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 2, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_03_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_03_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_06_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 5, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 5, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_06_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_06_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_12_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 11, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 11, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_12_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_12_ANT.CD_BVSP
UNION
SELECT        DIA_ATUAL.Data_Indicadores_Financeiros AS DT_MVTO, ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP, NOME_CLIENTE AS NOME_CLIENTE , 
                         0 AS NR_ESTRATEGIA , DIA_ATUAL.Descricao_Indicadores_Financeiros AS NM_ABREV, 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA, 0 AS VL_PL_ANTERIOR, 0 AS VL_PL_DIA, 0 AS COTA_DIA, dbo.TruncaFormata((DIA_ATUAL.Fator_Correcao_Indicadores_Financeiros - 1) * 100, 6, 'T') 
                         AS RENT_DIA, 0 AS COTA_MES_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_MES, 
                         0 AS COTA_ANO_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(ANO_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_ANO, 
                         0 AS COTA_MES_03_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_03_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_03, 
                         0 AS COTA_MES_06_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_06_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_06, 
                         0 AS COTA_MES_12_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_12_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_12, 
                         0 AS COTA_INICIO, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_INI.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_INICIO
FROM            ESTRATEGIA_CLIENTE_COTA_RENT INNER JOIN
                         ESTRATEGIA ON 1 = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                         ESTRATEGIA_CLIENTE_ASSOCIADO ON CASE WHEN ISNULL(ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP, 0) 
                         <> 0 THEN ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP ELSE 0 END = ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP AND 1 = ESTRATEGIA_CLIENTE_ASSOCIADO.NR_ESTRATEGIA AND 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA <= ESTRATEGIA_CLIENTE_COTA_RENT.DT_MVTO INNER JOIN
                         INDICADORES_FINANCEIROS AS DIA_ATUAL ON DT_MVTO = Data_Indicadores_Financeiros AND ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP = ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP INNER JOIN
                         dbo.Cliente ON ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente LEFT OUTER JOIN
                         INDICADORES_FINANCEIROS AS MES_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.Data_Indicadores_Financeiros) AS CHAR) + '/' + CAST(MONTH(DIA_ATUAL.Data_Indicadores_Financeiros) 
                         AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_ANT.Descricao_Indicadores_Financeiros LEFT JOIN
                         INDICADORES_FINANCEIROS AS ANO_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DATA_INDICADORES_FINANCEIROS) AS CHAR) + CAST('/01/01' AS CHAR) AS SMALLDATETIME), - 1) 
                         = ANO_ANT.Data_Indicadores_Financeiros AND DIA_ATUAL.Descricao_Indicadores_Financeiros = ANO_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_03_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 2, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 2, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_03_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_03_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_06_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 5, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 5, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_06_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_06_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_12_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 11, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 11, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_12_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_12_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_INI ON MES_INI.Data_Indicadores_Financeiros = DT_INICIO_ESTRATEGIA AND DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_INI.Descricao_Indicadores_Financeiros


GO


-- =============================================
-- Objeto:	[VW_SIM_SIS_INDICE]
-- Descri��o:	<View que os indicadores financeiros presentes na base do SIM>
-- Depend�ncias:	Depende de ->	dbo.Indicadores_Financeiros 
--					Dependem desta -> Vazio
-- =============================================
IF EXISTS (SELECT * FROM sysobjects WHERE name = 'VW_SIM_SIS_INDICE') 
begin
	exec('DROP VIEW [dbo].[VW_SIM_SIS_INDICE]')
end

GO

CREATE VIEW [dbo].[VW_SIM_SIS_INDICE]
AS
SELECT     Descricao_Indicadores_Financeiros AS NM_INDICE, Data_Indicadores_Financeiros AS DT_INDICE, Tipo_Indicadores_Financeiros AS TP_INDICE, NULL 
                      AS VL_VARIACAO_INDICE
FROM         dbo.indicadores_financeiros
GO


-- =============================================
-- Objeto:	[FN_ESTRATEGIA_FAT_COTA]
-- Descri��o:	<Fun��o recursiva que fornece os dados usados no gr�fico de evolu��o da carteira>
-- Depend�ncias:	Depende de -> dbo.ESTRATEGIA_CLIENTE_COTA_RENT
--					Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FN_ESTRATEGIA_FAT_COTA') 
begin
	exec('DROP FUNCTION [dbo].[FN_ESTRATEGIA_FAT_COTA]')
end

GO

CREATE FUNCTION [dbo].[FN_ESTRATEGIA_FAT_COTA] (@DT_INICIAL SMALLDATETIME , @DT_FINAL SMALLDATETIME , @CD_BVSP INT, @NR_ESTRATEGIA INT , @COTA_INICIAL INT)

RETURNS TABLE 

AS

RETURN 

(
WITH TABFAT (DT_MVTO,[CD_BVSP],[NR_ESTRATEGIA], DS_ESTRATEGIA,  FILHO, PAI, FAT_ESTRATEGIA , COTA_ESTRATEGIA)
AS
(
SELECT [DT_MVTO],[CD_BVSP],[NR_ESTRATEGIA]  , NM_ABREV_ESTRATEGIA AS DS_ESTRATEGIA ,  filho, pai, cast(FAT_ESTRATEGIA as float) ,  CONVERT(DECIMAL(16,8),@COTA_INICIAL) AS COTA_ESTRATEGIA

FROM (SELECT  [DT_MVTO],[CD_BVSP] ,[NR_ESTRATEGIA], NM_ABREV_ESTRATEGIA , linha filho , linha-1 as pai, FAT_ESTRATEGIA FROM (

SELECT [DT_MVTO],[CD_BVSP],1 AS NR_ESTRATEGIA , 'CARTEIRA' AS NM_ABREV_ESTRATEGIA, ((VL_RENT_TAXA / 100)+1) AS FAT_ESTRATEGIA , ROW_NUMBER() over( partition by  'CARTEIRA' order by [DT_MVTO]) LINHA FROM  [ESTRATEGIA_CLIENTE_COTA_RENT] S
WHERE S.[CD_BVSP]  = @CD_BVSP
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND 1 = @NR_ESTRATEGIA 
)A) S   
WHERE  PAI = 0
UNION ALL 
SELECT S.[DT_MVTO], S.[CD_BVSP], S.NR_ESTRATEGIA , S.NM_ABREV_ESTRATEGIA, S.FILHO, S.PAI, cast(S.FAT_ESTRATEGIA as float),  CONVERT(DECIMAL( 16,8), S.FAT_ESTRATEGIA * B.COTA_ESTRATEGIA)
FROM (SELECT [DT_MVTO],[CD_BVSP], NR_ESTRATEGIA , NM_ABREV_ESTRATEGIA, linha filho , linha-1 as pai,  FAT_ESTRATEGIA FROM (
SELECT  [DT_MVTO],[CD_BVSP],1 AS NR_ESTRATEGIA ,  'CARTEIRA' AS NM_ABREV_ESTRATEGIA, ((VL_RENT_TAXA / 100)+1) AS FAT_ESTRATEGIA, ROW_NUMBER() over(partition by  'CARTEIRA' order by [DT_MVTO]) LINHA FROM [ESTRATEGIA_CLIENTE_COTA_RENT] S
WHERE S.[CD_BVSP] = @CD_BVSP 
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND 1 = @NR_ESTRATEGIA 

)A)S
JOIN TABFAT B
ON S.PAI = B.FILHO
)                          
SELECT * FROM TABFAT 
)

GO


-- =============================================
-- FLAGS
-- =============================================


insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('listaIndicadoresGraficos', 'CDI;IBOVESPA' , 'Determina os indicadores fixos informados pela corretora, separados por ponto e v�rgula (;)', 'N')


insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('CalcDtInicialGrafico', '0',  'Determina o numero de meses usado para calcular a data inicial do gr�fico evolu��o; Para primeiro dia do ano preencher com 0 (zero)', 'N')

insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('ConsultaDefaultCarteira', '1',  'Determina o valor default selecionado para a consulta de carteira cont�bil. Op��es= 0 (Estrat�gia); 1 (Cota); 2 (ClubeseFundos)', 'N')






