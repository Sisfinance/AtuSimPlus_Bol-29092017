/****** Object:  Table [dbo].[Pos_DBTC]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Pos_DBTC]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Pos_DBTC](
	[Data_Arquivo_DBTC] [smalldatetime] NOT NULL,
	[Numero_Contrato_DBTC] [int] NOT NULL,
	[Compra_Venda_DBTC] [char](1) NOT NULL,
	[Data_Origem_DBTC] [datetime] NULL,
	[Data_Abert_DBTC] [datetime] NULL,
	[Data_Venc_DBTC] [datetime] NULL,
	[Data_Caren_DBTC] [datetime] NULL,
	[Codigo_Cliente_DBTC] [int] NOT NULL,
	[Carteira_Destino_DBTC] [int] NULL,
	[Qtd_DBTC] [int] NOT NULL,
	[Pu_DBTC] [float] NULL,
	[Taxa_Remuneracao_DBTC] [float] NULL,
	[Taxa_Comissao_DBTC] [float] NULL,
	[Qtd_Original_DBTC] [float] NULL,
	[Papel_DBTC] [varchar](12) NULL,
	[Pu_Anterior_DBTC] [float] NULL,
	[Devolucao_ant_DBTC] [char](3) NULL,
	[Valorizacao_ant_DBTC] [char](3) NULL,
	[Recebimento_Periodico_DBTC] [char](3) NULL,
	[Opcao_Recebimento_DBTC] [nvarchar](60) NULL,
	[Forma_contr_gerado_DBTC] [nvarchar](60) NULL,
	[num_contr_original_DBTC] [int] NULL,
	[Nome_Cliente_DBTC] [nvarchar](120) NULL,
 CONSTRAINT [PK_DBTC] PRIMARY KEY CLUSTERED 
(
	[Data_Arquivo_DBTC] ASC,
	[Numero_Contrato_DBTC] ASC,
	[Codigo_Cliente_DBTC] ASC,
	[Qtd_DBTC] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DBTL]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DBTL]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DBTL](
	[Data_Arquivo_DBTL] [smalldatetime] NULL,
	[Tipo_Registro_DBTL] [int] NULL,
	[Num_DBTL] [int] NOT NULL,
	[Posicao_DBTL] [char](1) NULL,
	[Cod_Cliente_DBTL] [int] NULL,
	[Data_Liq_DBTL] [smalldatetime] NULL,
	[Qtd_acoes_DBTL] [float] NULL,
	[Cod_Usu_cust_DBTL] [numeric](18, 0) NULL,
	[Cod_Cli_Cust_DBTL] [numeric](18, 0) NULL,
	[Cod_Cart_Liq_DBTL] [char](5) NULL,
	[qtd_inadimplente_DBTL] [numeric](18, 0) NULL,
	[codigo_ISIN_DBTL] [char](12) NULL,
	[Num_Distr_DBTL] [numeric](18, 0) NULL,
	[Num_Parcela_DBTL] [numeric](18, 0) NULL,
	[Cod_Empresa_DBTL] [numeric](18, 0) NULL,
	[Descr_Lanc_DBTL] [nvarchar](50) NULL,
	[Tipo_Lanc_DBTL] [char](1) NULL,
	[Valor_Lanc_DBTL] [float] NULL,
	[Papel_DBTL] [char](12) NULL,
	[Dias_Uteis_DBTL] [int] NULL,
	[Descr_Lanc_DBTL_3] [nvarchar](50) NULL,
	[Valor_Lanc_DBTL_3] [float] NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[DBTC]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DBTC]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[DBTC](
	[Data_Arquivo_DBTC] [smalldatetime] NULL,
	[Numero_Contrato_DBTC] [int] NOT NULL,
	[Compra_Venda_DBTC] [char](1) NULL,
	[Data_Origem_DBTC] [datetime] NULL,
	[Data_Abert_DBTC] [datetime] NULL,
	[Data_Venc_DBTC] [datetime] NULL,
	[Data_Caren_DBTC] [datetime] NULL,
	[Codigo_Cliente_DBTC] [int] NULL,
	[Carteira_Destino_DBTC] [int] NULL,
	[Qtd_DBTC] [int] NULL,
	[Pu_DBTC] [float] NULL,
	[Taxa_Remuneracao_DBTC] [float] NULL,
	[Taxa_Comissao_DBTC] [float] NULL,
	[Qtd_Original_DBTC] [float] NULL,
	[Papel_DBTC] [varchar](12) NULL,
	[Pu_Anterior_DBTC] [float] NULL,
	[Devolucao_ant_DBTC] [char](3) NULL,
	[Valorizacao_ant_DBTC] [char](3) NULL,
	[Recebimento_Periodico_DBTC] [char](3) NULL,
	[Opcao_Recebimento_DBTC] [nvarchar](60) NULL,
	[Forma_contr_gerado_DBTC] [nvarchar](60) NULL,
	[num_contr_original_DBTC] [int] NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Cmdf_Aux]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cmdf_Aux]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cmdf_Aux](
	[Data_Arquivo_cmdf_aux] [smalldatetime] NULL,
	[Tipo_Reg_cmdf_aux] [char](2) NULL,
	[Ident_Lanc_cmdf_aux] [nvarchar](26) NULL,
	[Num_Ref_cmdf_aux] [int] NULL,
	[Data_cmdf_aux] [smalldatetime] NULL,
	[Cod_Cliente_cmdf_aux] [int] NULL,
	[Cod_Lanca_cmdf_aux] [int] NULL,
	[Descr_Lanca_cmdf_aux] [nvarchar](60) NULL,
	[DebCred_cmdf_aux] [char](1) NULL,
	[Cod_Grupo_cmdf_aux] [int] NULL,
	[Descr_Grupo_cmdf_aux] [nvarchar](35) NULL,
	[Descr_Ref_Lanca_cmdf_aux] [nvarchar](40) NULL,
	[Valor_cmdf_aux] [float] NULL,
	[Valor_Emprestimo_cmdf_aux] [float] NULL,
	[Qtd_cmdf_aux] [float] NULL,
	[Papel_cmdf_aux] [nvarchar](12) NULL,
	[Isin_cmdf_aux] [nvarchar](12) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BdPregao_Bmf_Aux]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BdPregao_Bmf_Aux]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BdPregao_Bmf_Aux](
	[Data_Bdpregao_Bmf_Aux] [smalldatetime] NOT NULL,
	[Papel_Bdpregao_Bmf_Aux] [nvarchar](8) NOT NULL,
	[Mercadoria_Bdpregao_Bmf_Aux] [nvarchar](3) NULL,
	[Vencimento_Serie_Bdpregao_Bmf_Aux] [nvarchar](5) NULL,
	[Tipo_Mercado_Bdpregao_Bmf_Aux] [nvarchar](3) NOT NULL,
	[Pu_Base_Bdpregao_Bmf_Aux] [float] NULL,
	[Valor_Ponto_Bdpregao_Bmf_Aux] [float] NULL,
	[Ajuste_Emolumentos_Bdpregao_Bmf_Aux] [float] NULL,
	[Ajuste_Anterior_Bdpregao_Bmf_Aux] [float] NULL,
	[Ajuste_Atual_Bdpregao_Bmf_Aux] [float] NULL,
	[Ajuste_Exercicio_Bdpregao_Bmf_Aux] [float] NULL,
	[Pu_Fechamento_Bdpregao_Bmf_Aux] [float] NULL,
	[Pu_Medio_Bdpregao_Bmf_Aux] [float] NULL,
	[Tipo_Opcao_Bdpregao_Bmf_Aux] [nvarchar](1) NULL,
	[Data_Vencimento_Bdpregao_Bmf_Aux] [smalldatetime] NULL,
	[Num_Casas_Decimais_Ajustes_Bdpregao_Bmf_Aux] [float] NULL,
	[Num_Casas_Decimais_Cotacoes_Bdpregao_Bmf_Aux] [float] NULL,
	[Valor_Dolar_Bdpregao_Bmf_Aux] [float] NULL,
	[Qtd_Saques_Venc_Bdpregao_Bmf_Aux] [float] NULL,
	[Qtd_Dias_Uteis_Venc_Bdpregao_Bmf_Aux] [float] NULL,
	[Qtd_Dias_Corridos_Venc_Bdpregao_Bmf_Aux] [float] NULL,
	[Seq_Venc_Fut_Bdpregao_Bmf_Aux] [float] NULL,
	[Cotacao_Automatica_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_Normal_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_Normal_Soc_Efetivo_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_Normal_Inv_Institucional_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_Normal_Soc_Investidor_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_DT_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_DT_Soc_Efetivo_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_DT_Inv_Institucional_Bdpregao_Bmf_Aux] [float] NULL,
	[Emolumento_DT_Soc_Investidor_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_Normal_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_Normal_Soc_Efetivo_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_Normal_Inv_Institucional_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_Normal_Soc_Investidor_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_DT_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_DT_Soc_Efetivo_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_DT_Inv_Institucional_Bdpregao_Bmf_Aux] [float] NULL,
	[Tx_Registro_DT_Soc_Investidor_Bdpregao_Bmf_Aux] [float] NULL,
	[Fator_Lambda_Bdpregao_Bmf_Aux] [float] NULL,
	[Fator_P_Bdpregao_Bmf_Aux] [float] NULL,
	[Fator_P_Soc_Efetivo_BdPregao_Bmf_Aux] [float] NULL,
	[Fator_P_Inv_Institucional_BdPregao_Bmf_Aux] [float] NULL,
	[Fator_P_Soc_Investidor_BdPregao_Bmf_Aux] [float] NULL,
	[Qtd_Contratos_BdPregao_Bmf_Aux] [float] NULL,
	[Qtd_Negocios_BdPregao_Bmf_Aux] [float] NULL,
	[Volume_BdPregao_Bmf_Aux] [float] NULL,
	[Qtd_Contratos_Abertos_BdPregao_Bmf_Aux] [float] NULL,
	[Volume_Exercido_BdPregao_Bmf_Aux] [float] NULL,
	[Cot_Ult_Neg_BdPregao_Bmf_Aux] [float] NULL,
	[Isin_Bdpregao_Aux] [nvarchar](12) NULL,
 CONSTRAINT [PK_BdPregao_Bmf_Aux] PRIMARY KEY CLUSTERED 
(
	[Data_Bdpregao_Bmf_Aux] ASC,
	[Papel_Bdpregao_Bmf_Aux] ASC,
	[Tipo_Mercado_Bdpregao_Bmf_Aux] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[BDIN_AUX]    Script Date: 07/20/2017 11:33:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BDIN_AUX]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[BDIN_AUX](
	[Data_BDIN] [smalldatetime] NOT NULL,
	[Nome_BDIN] [nvarchar](12) NOT NULL,
	[Tipo_BDIN] [nvarchar](1) NULL,
	[Tipo_Mercado_BDIN] [nvarchar](3) NULL,
	[Lote_BDIN] [int] NULL,
	[Indbov_BDIN] [smallint] NULL,
	[Codigo_Isin_BDIN] [nvarchar](12) NULL,
	[Codigo_Objeto_Papel_BDIN] [nvarchar](12) NULL,
	[Nome_Empresa_BDIN] [nvarchar](12) NULL,
	[Especificacao_BDIN] [nvarchar](10) NULL,
	[Data_Venc_Opc_BDIN] [smalldatetime] NULL,
	[Pu_Fec_BDIN] [float] NULL,
	[Pu_Med_BDIN] [float] NULL,
	[Pu_Abe_BDIN] [float] NULL,
	[Pu_Max_BDIN] [float] NULL,
	[Pu_Min_BDIN] [float] NULL,
	[Pu_Exe_BDIN] [float] NULL,
	[Cotacao_Automatica_BDIN] [nvarchar](1) NOT NULL,
	[Data_inicio_BDIN] [smalldatetime] NULL,
	[Data_limite_BDIN] [smalldatetime] NULL,
 CONSTRAINT [PK_BDIN_AUX] PRIMARY KEY CLUSTERED 
(
	[Data_BDIN] ASC,
	[Nome_BDIN] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END