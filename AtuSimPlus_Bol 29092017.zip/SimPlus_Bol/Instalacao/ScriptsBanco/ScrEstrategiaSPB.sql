/*TABELAS DA ESTRATEGIA SIMPLUSBOLSA */

-- =============================================
-- Tabela:   [ESTRATEGIA]
-- Descri��o: <Tabela que armazena dados de Estrat�gia>
-- Depend�ncias:    Depende de -> dbo.V_ESTRATEGIA_CLIENTE, dbo.V_ESTRATEGIA_CLIENTE_COTA, dbo.V_ESTRATEGIA_CLIENTE_RENT
--                                Dependem desta -> Vazio
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA](
       [NR_ESTRATEGIA] [int] IDENTITY(1,1) NOT NULL,
       [NM_ABREV_ESTRATEGIA] [nvarchar](30) NULL,
       [DS_ESTRATEGIA] [varchar](255) NULL,
CONSTRAINT [PK_Estrategia_ok] PRIMARY KEY CLUSTERED 
(
       [NR_ESTRATEGIA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_CLIENTE]
-- Descri��o: <Tabela que armazena dados de Estrat�gia por cliente>
-- Depend�ncias:    Depende de -> SP_FECHAMENTO_ESTRATEGIA
--                                Dependem desta -> Vazio
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_CLIENTE](
       [NR_ESTRATEGIA] [int] NOT NULL,
       [TP_INVESTIMENTO] [nvarchar](5) NOT NULL,
       [SETOR] [nvarchar](100) NOT NULL,
       [TP_MERCADO] [nvarchar](3) NOT NULL,
       [COD_OBJ] [nvarchar](12) NOT NULL,
       [NM_ATIVO] [nvarchar](12) NOT NULL,
CONSTRAINT [PK_ESTRATEGIA_CLIENTE] PRIMARY KEY CLUSTERED 
(
       [NR_ESTRATEGIA] ASC,
       [TP_INVESTIMENTO] ASC,
       [SETOR] ASC,
       [TP_MERCADO] ASC,
       [COD_OBJ] ASC,
       [NM_ATIVO] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_CLIENTE_ASSOCIADO]
-- Descri��o: <Tabela que armazena dados de Estrat�gia>
-- Depend�ncias:    Depende de -> SP_FECHAMENTO_ESTRATEGIA, dbo.V_ESTRATEGIA_CLIENTE, dbo.V_ESTRATEGIA_CLIENTE_COTA
--                                Dependem desta -> Vazio
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_CLIENTE_ASSOCIADO](
       [CD_BVSP] [int] NOT NULL,
       [NR_ESTRATEGIA] [int] NOT NULL,
       [DT_INICIO_ESTRATEGIA] [smalldatetime] NULL,
       [COTA_INICIAL] [decimal](18, 8) NULL,
CONSTRAINT [PK_Cliente_Estrategia] PRIMARY KEY CLUSTERED 
(
       [CD_BVSP] ASC,
       [NR_ESTRATEGIA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_TAXA]
-- Descri��o: <Tabela que armazena dados de Taxa de estrat�gia>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> Vazio
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_TAXA](
       [CODNUM] [int] IDENTITY(1,1) NOT NULL,
       [NM_TAXA] [nvarchar](12) NULL,
       [DS_TAXA] [nvarchar](50) NULL,
CONSTRAINT [PK_ESTRATEGIA_TAXA] PRIMARY KEY CLUSTERED 
(
       [CODNUM] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_TAXA_CLIENTE]
-- Descri��o: <Tabela que armazena dados de Taxa de estrategia por cliente>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> Vazio
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_TAXA_CLIENTE](
       [CODNUM_TAXA] [int] NOT NULL,
       [CD_BVSP] [int] NOT NULL,
       [DT_INI] [smalldatetime] NOT NULL,
       [DT_FIM] [smalldatetime] NOT NULL,
       [TP_TAXA] [nchar](3) NULL,
       [TP_DIA] [nchar](1) NULL,
       [PL_DIA] [int] NULL,
       [TP_COBRANCA] [nchar](1) NULL,
       [DIA_PAG] [int] NULL,
       [VL_TAX_FIX] [decimal](12, 6) NULL,
       [VL_MINIMO] [decimal](18, 2) NULL,
CONSTRAINT [PK_ESTRATEGIA_TAXA_CLIENTE] PRIMARY KEY CLUSTERED 
(
       [CODNUM_TAXA] ASC,
       [CD_BVSP] ASC,
       [DT_INI] ASC,
       [DT_FIM] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_CLIENTE_RENT]
-- Descri��o: <Tabela que armazena dados de rentabilidade por estrategia para cada cliente>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> dbo.V_ESTRATEGIA_CLIENTE, dbo.V_ESTRATEGIA_CLIENTE_RENT
-- =============================================


CREATE TABLE [dbo].[ESTRATEGIA_CLIENTE_RENT](
       [DT_MVTO] [smalldatetime] NOT NULL,
       [CD_BVSP] [int] NOT NULL,
       [NR_ESTRATEGIA] [int] NOT NULL,
       [VL_PL_ANTERIOR] [float] NULL,
       [VL_PL_DIA] [float] NULL,
       [VL_RENT_TAXA] [float] NULL,
       [VL_COTA_TAXA] [float] NULL,
       [VL_RENT_PERF] [float] NULL,
       [VL_COTA_PERF] [float] NULL,
       [VL_PROVISOES] [float] NULL,
CONSTRAINT [PK_ESTRATEGIA_CLIENTE_RENT] PRIMARY KEY CLUSTERED 
(
       [DT_MVTO] ASC,
       [CD_BVSP] ASC,
       [NR_ESTRATEGIA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


-- =============================================
-- Tabela:   [ESTRATEGIA_CLIENTE_COTA_RENT]
-- Descri��o: <Tabela que armazena dados de rentabilidade da carteira para cada cliente>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> dbo.FN_ESTRATEGIA_FAT_COTA, dbo.V_ESTRATEGIA_CLIENTE_COTA
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_CLIENTE_COTA_RENT](
       [DT_MVTO] [smalldatetime] NOT NULL,
       [CD_BVSP] [int] NOT NULL,
       [VL_RENT_TAXA] [decimal](18, 8) NULL,
       [VL_COTA_TAXA] [decimal](18, 8) NULL,
       [VL_PL_ANTERIOR] [decimal](18, 2) NULL,
       [VL_PL_DIA] [decimal](18, 2) NULL,
       [VL_PL_CARTEIRA] [decimal](18, 2) NULL,
       [VL_APL_RESG] [decimal](18, 2) NULL,
       [VL_PROVISOES_ANTERIOR] [decimal](18, 2) NULL,
       [VL_PROVISOES_DIA] [decimal](18, 2) NULL,
       [VL_MERCADO_ANTERIOR] [decimal](18, 2) NULL,
       [VL_MERCADO_DIA] [decimal](18, 2) NULL,
CONSTRAINT [PK_ESTRATEGIA_CLIENTE_COTA_RENT] PRIMARY KEY CLUSTERED 
(
       [DT_MVTO] ASC,
       [CD_BVSP] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_PROVISAO_COTA]
-- Descri��o: <Tabela que armazena dados de provis�es da carteira para cada cliente>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> dbo.FN_ESTRATEGIA_FAT_COTA, dbo.V_ESTRATEGIA_CLIENTE_COTA
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_PROVISAO_COTA](
       [DT_MVTO] [smalldatetime] NOT NULL,
       [CD_BVSP] [int] NOT NULL,
       [NR_ESTRATEGIA] [int] NOT NULL,
       [TP_PROVISAO] [char](6) NOT NULL,
       [DT_INI] [smalldatetime] NOT NULL,
       [DT_FIM] [smalldatetime] NOT NULL,
       [DS_ATIVO] [nvarchar](12) NOT NULL,
       [NUMSEQ] [int] NOT NULL,
       [DS_PROVISAO] [nvarchar](100) NOT NULL,
       [QTD_ATIVO_DIVJRS] [int] NULL,
       [PERC_DIVJRS] [decimal](18, 12) NULL,
       [VL_ANTERIOR] [decimal](18, 2) NULL,
       [VL_ATUAL] [decimal](18, 2) NULL,
CONSTRAINT [PK_ESTRATEGIA_PROVISAO_COTA] PRIMARY KEY CLUSTERED 
(
       [DT_MVTO] ASC,
       [CD_BVSP] ASC,
       [NR_ESTRATEGIA] ASC,
       [TP_PROVISAO] ASC,
       [DT_INI] ASC,
       [DT_FIM] ASC,
       [DS_ATIVO] ASC,
       [NUMSEQ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

-- =============================================
-- Tabela:   [ESTRATEGIA_INDICADOR_RENT]
-- Descri��o: <Tabela que armazena dados de indicadores para uso em V_ESTRATEGIA_CLIENTE_RENT>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> 
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_INDICADOR_RENT](
       [DT_MVTO] [smalldatetime] NOT NULL,
       [CD_BVSP] [int] NOT NULL,
       [DS_ESTRATEGIA] [nvarchar](30) NOT NULL,
       [VL_PL_ANTERIOR] [float] NULL,
       [VL_PL_DIA] [float] NULL,
       [VL_RENT_TAXA] [float] NULL,
       [VL_COTA_TAXA] [float] NULL,
       [VL_RENT_PERF] [float] NULL,
       [VL_COTA_PERF] [float] NULL,
       [VL_PROVISOES] [float] NULL,
CONSTRAINT [PK_ESTRATEGIA_INDICADOR_RENT] PRIMARY KEY CLUSTERED 
(
       [DT_MVTO] ASC,
       [CD_BVSP] ASC,
       [DS_ESTRATEGIA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [ESTRATEGIA_APLRESG_CLUBE_FUNDO]
-- Descri��o: <>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> 
-- =============================================

CREATE TABLE [dbo].[ESTRATEGIA_APLRESG_CLUBE_FUNDO](
	[DT_MVTO] [smalldatetime] NOT NULL,
	[CD_BVSP] [int] NOT NULL,
	[CD_BVSP_CLUBE_FUNDO] [int] NOT NULL,
	[DT_INI] [smalldatetime] NOT NULL,
	[DT_FIM] [smalldatetime] NOT NULL,
	[Valor] [decimal](18, 2) NULL,
	[IR_Finan] [decimal](18, 2) NULL,
	[IOF_Finan] [decimal](18, 2) NULL,
	[DTHR_LANCAMENTO] [datetime] NULL,
 CONSTRAINT [PK_ESTRATEGIA_APLRESG_CLUBE_FUNDO] PRIMARY KEY CLUSTERED 
(
	[DT_MVTO] ASC,
	[CD_BVSP] ASC,
	[CD_BVSP_CLUBE_FUNDO] ASC,
	[DT_INI] ASC,
	[DT_FIM] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-- =============================================
-- Tabela:   [TCCMOVTO]
-- Descri��o: <>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> 
-- =============================================

CREATE TABLE [dbo].[TCCMOVTO](
	[DT_LIQUIDACAO] [smalldatetime] NOT NULL,
	[CD_CLIENTE] [int] NOT NULL,
	[NR_LANCAMENTO] [int] NOT NULL,
	[ACAO_SIM] [int] NOT NULL,
	[DT_REFERENCIA] [smalldatetime] NULL,
	[DS_LANCAMENTO] [nvarchar](100) NULL,
	[DT_LANCAMENTO] [smalldatetime] NULL,
	[VL_LANCAMENTO] [decimal](18, 2) NULL,
	[IN_ORIGEM] [nvarchar](1) NULL,
	[CD_HISTORICO] [int] NULL,
	[DT_VALOR] [smalldatetime] NULL,
	[CD_ATIVIDADE] [nvarchar](3) NULL,
	[DTHR_LANCAMENTO] [datetime] NULL,
 CONSTRAINT [PK_TCCMOVTO] PRIMARY KEY CLUSTERED 
(
	[DT_LIQUIDACAO] ASC,
	[CD_CLIENTE] ASC,
	[NR_LANCAMENTO] ASC,
	[ACAO_SIM] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/*VIEWS USADAS PELO SIMPLUSBOLSA */
-- =============================================
-- Funcao:   [V_ESTRATEGIA_CLIENTE]
-- Descri��o: <View que lista o rendimento da estrategia>
-- Depend�ncias:    Depende de -> dbo.PROX_DIA_UTIL, dbo.TruncaFormata, dbo.Cliente
--                                Dependem desta -> Vazio
-- =============================================


IF EXISTS (SELECT * FROM sysobjects WHERE name = 'V_ESTRATEGIA_CLIENTE') 
begin
       exec('DROP VIEW [dbo].[V_ESTRATEGIA_CLIENTE]')
end

GO
CREATE VIEW [dbo].[V_ESTRATEGIA_CLIENTE]
AS
SELECT     DIA_ATUAL.DT_MVTO, DIA_ATUAL.CD_BVSP, dbo.Cliente.nome_cliente, DIA_ATUAL.NR_ESTRATEGIA AS NR_ESTRATEGIA, dbo.ESTRATEGIA.NM_ABREV_ESTRATEGIA, 
                      DIA_ATUAL.VL_PL_ANTERIOR, DIA_ATUAL.VL_PL_DIA, DIA_ATUAL.VL_COTA_TAXA AS COTA_DIA, DIA_ATUAL.VL_RENT_TAXA AS RENT_DIA, 
                      ISNULL(MES_ANT.VL_COTA_TAXA, 1) AS COTA_MES_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_ANT.VL_COTA_TAXA, 1) - 1) * 100, 6, N'T') 
                      AS RENT_MES, ISNULL(ANO_ANT.VL_COTA_TAXA, 1) AS COTA_ANO_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(ANO_ANT.VL_COTA_TAXA, 1) - 1) 
                      * 100, 6, N'T') AS RENT_ANO, ISNULL(MES_03_ANT.VL_COTA_TAXA, 1) AS COTA_MES_03_ANT, 
                      dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_03_ANT.VL_COTA_TAXA, 1) - 1) * 100, 6, N'T') AS RENT_03, ISNULL(MES_06_ANT.VL_COTA_TAXA, 1) 
                      AS COTA_MES_06_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_06_ANT.VL_COTA_TAXA, 1) - 1) * 100, 6, N'T') AS RENT_06, 
                      ISNULL(MES_12_ANT.VL_COTA_TAXA, 1) AS COTA_MES_12_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_12_ANT.VL_COTA_TAXA, 1) - 1) * 100,
                       6, N'T') AS RENT_12
FROM         dbo.ESTRATEGIA_CLIENTE_RENT AS DIA_ATUAL INNER JOIN
                      dbo.ESTRATEGIA ON DIA_ATUAL.NR_ESTRATEGIA = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                      dbo.Cliente ON DIA_ATUAL.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente LEFT OUTER JOIN
                      dbo.ESTRATEGIA_CLIENTE_RENT AS MES_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + '/' + CAST(MONTH(DIA_ATUAL.DT_MVTO)
                       AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_ANT.CD_BVSP AND 
                      DIA_ATUAL.NR_ESTRATEGIA = MES_ANT.NR_ESTRATEGIA LEFT OUTER JOIN
                      dbo.ESTRATEGIA_CLIENTE_RENT AS ANO_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + CAST('/01/01' AS CHAR) 
                      AS SMALLDATETIME), - 1) = ANO_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = ANO_ANT.CD_BVSP AND 
                      DIA_ATUAL.NR_ESTRATEGIA = ANO_ANT.NR_ESTRATEGIA LEFT OUTER JOIN
                      dbo.ESTRATEGIA_CLIENTE_RENT AS MES_03_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 2, DIA_ATUAL.DT_MVTO)) AS CHAR) 
                      + '/' + CAST(MONTH(DATEADD(MONTH, - 2, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_03_ANT.DT_MVTO AND 
                      DIA_ATUAL.CD_BVSP = MES_03_ANT.CD_BVSP AND DIA_ATUAL.NR_ESTRATEGIA = MES_03_ANT.NR_ESTRATEGIA LEFT OUTER JOIN
                      dbo.ESTRATEGIA_CLIENTE_RENT AS MES_06_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 5, DIA_ATUAL.DT_MVTO)) AS CHAR) 
                      + '/' + CAST(MONTH(DATEADD(MONTH, - 5, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_06_ANT.DT_MVTO AND 
                      DIA_ATUAL.CD_BVSP = MES_06_ANT.CD_BVSP AND DIA_ATUAL.NR_ESTRATEGIA = MES_06_ANT.NR_ESTRATEGIA LEFT OUTER JOIN
                      dbo.ESTRATEGIA_CLIENTE_RENT AS MES_12_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 11, DIA_ATUAL.DT_MVTO)) AS CHAR) 
                      + '/' + CAST(MONTH(DATEADD(MONTH, - 11, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_12_ANT.DT_MVTO AND 
                      DIA_ATUAL.CD_BVSP = MES_12_ANT.CD_BVSP AND DIA_ATUAL.NR_ESTRATEGIA = MES_12_ANT.NR_ESTRATEGIA


GO


-- =============================================
-- Funcao:   [V_ESTRATEGIA_CLIENTE_COTA]
-- Descri��o: <View que lista o rendimento da cota da carteira>
-- Depend�ncias:    Depende de -> dbo.PROX_DIA_UTIL, dbo.TruncaFormata, dbo.ESTRATEGIA
--                                                          dbo.ESTRATEGIA_CLIENTE_ASSOCIADO, dbo.Indicadores_Financeiros
--                                                          dbo.ESTRATEGIA_CLIENTE_COTA_RENT, dbo.Cliente
--                                Dependem desta -> Vazio
-- =============================================


IF EXISTS (SELECT * FROM sysobjects WHERE name = 'V_ESTRATEGIA_CLIENTE_COTA') 
begin
       exec('DROP VIEW [dbo].[V_ESTRATEGIA_CLIENTE_COTA]')
end

GO

CREATE VIEW [dbo].[V_ESTRATEGIA_CLIENTE_COTA]
AS
SELECT        DIA_ATUAL.DT_MVTO, DIA_ATUAL.CD_BVSP, dbo.Cliente.nome_cliente AS NOME_CLIENTE, ESTRATEGIA.NR_ESTRATEGIA AS NR_ESTRATEGIA, ESTRATEGIA.NM_ABREV_ESTRATEGIA AS NM_ABREV, ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA, 
                         DIA_ATUAL.VL_PL_ANTERIOR, DIA_ATUAL.VL_PL_DIA, DIA_ATUAL.VL_COTA_TAXA AS COTA_DIA, DIA_ATUAL.VL_RENT_TAXA AS RENT_DIA, ISNULL(MES_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_MES_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_MES, ISNULL(ANO_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_ANO_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(ANO_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_ANO, ISNULL(MES_03_ANT.VL_COTA_TAXA, COTA_INICIAL) AS COTA_MES_03_ANT, 
                         dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_03_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_03, ISNULL(MES_06_ANT.VL_COTA_TAXA, COTA_INICIAL) 
                         AS COTA_MES_06_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_06_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_06, ISNULL(MES_12_ANT.VL_COTA_TAXA, 
                         COTA_INICIAL) AS COTA_MES_12_ANT, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(MES_12_ANT.VL_COTA_TAXA, COTA_INICIAL) - 1) * 100, 6, N'T') AS RENT_12, ISNULL(COTA_INICIAL, 1) 
                         AS COTA_INICIO, dbo.TruncaFormata((DIA_ATUAL.VL_COTA_TAXA / ISNULL(COTA_INICIAL, 1) - 1) * 100, 6, N'T') AS RENT_INICIO
FROM            dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS DIA_ATUAL INNER JOIN
                         dbo.ESTRATEGIA ON 1 = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                         ESTRATEGIA_CLIENTE_ASSOCIADO ON ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP = CASE WHEN ISNULL(ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP, 0) <> 0 THEN DIA_ATUAL.CD_BVSP ELSE 0 END AND 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.NR_ESTRATEGIA = 1 AND ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA <= DIA_ATUAL.DT_MVTO INNER JOIN
                         dbo.Cliente ON DIA_ATUAL.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + '/' + CAST(MONTH(DIA_ATUAL.DT_MVTO) AS CHAR) + '/' + CAST('01' AS CHAR) 
                         AS SMALLDATETIME), - 1) = MES_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS ANO_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DT_MVTO) AS CHAR) + CAST('/01/01' AS CHAR) AS SMALLDATETIME), - 1) = ANO_ANT.DT_MVTO AND 
                         DIA_ATUAL.CD_BVSP = ANO_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_03_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 2, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 2, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_03_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_03_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_06_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 5, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 5, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_06_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_06_ANT.CD_BVSP LEFT OUTER JOIN
                         dbo.ESTRATEGIA_CLIENTE_COTA_RENT AS MES_12_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 11, DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 11, 
                         DIA_ATUAL.DT_MVTO)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_12_ANT.DT_MVTO AND DIA_ATUAL.CD_BVSP = MES_12_ANT.CD_BVSP
UNION
SELECT        DIA_ATUAL.Data_Indicadores_Financeiros AS DT_MVTO, ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP, NOME_CLIENTE AS NOME_CLIENTE , 
                         0 AS NR_ESTRATEGIA , DIA_ATUAL.Descricao_Indicadores_Financeiros AS NM_ABREV, 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA, 0 AS VL_PL_ANTERIOR, 0 AS VL_PL_DIA, 0 AS COTA_DIA, dbo.TruncaFormata((DIA_ATUAL.Fator_Correcao_Indicadores_Financeiros - 1) * 100, 6, 'T') 
                         AS RENT_DIA, 0 AS COTA_MES_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_MES, 
                         0 AS COTA_ANO_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(ANO_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_ANO, 
                         0 AS COTA_MES_03_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_03_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_03, 
                         0 AS COTA_MES_06_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_06_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_06, 
                         0 AS COTA_MES_12_ANT, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_12_ANT.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_12, 
                         0 AS COTA_INICIO, dbo.TruncaFormata((DIA_ATUAL.Valor_Corrigido_Indicadores_Financeiros / ISNULL(MES_INI.Valor_Corrigido_Indicadores_Financeiros, 1) - 1) * 100, 6, N'T') AS RENT_INICIO
FROM            ESTRATEGIA_CLIENTE_COTA_RENT INNER JOIN
                         ESTRATEGIA ON 1 = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                         ESTRATEGIA_CLIENTE_ASSOCIADO ON CASE WHEN ISNULL(ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP, 0) 
                         <> 0 THEN ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP ELSE 0 END = ESTRATEGIA_CLIENTE_ASSOCIADO.CD_BVSP AND 1 = ESTRATEGIA_CLIENTE_ASSOCIADO.NR_ESTRATEGIA AND 
                         ESTRATEGIA_CLIENTE_ASSOCIADO.DT_INICIO_ESTRATEGIA <= ESTRATEGIA_CLIENTE_COTA_RENT.DT_MVTO INNER JOIN
                         INDICADORES_FINANCEIROS AS DIA_ATUAL ON DT_MVTO = Data_Indicadores_Financeiros AND ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP = ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP INNER JOIN
                         dbo.Cliente ON ESTRATEGIA_CLIENTE_COTA_RENT.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente LEFT OUTER JOIN
                         INDICADORES_FINANCEIROS AS MES_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.Data_Indicadores_Financeiros) AS CHAR) + '/' + CAST(MONTH(DIA_ATUAL.Data_Indicadores_Financeiros) 
                         AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_ANT.Descricao_Indicadores_Financeiros LEFT JOIN
                         INDICADORES_FINANCEIROS AS ANO_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DIA_ATUAL.DATA_INDICADORES_FINANCEIROS) AS CHAR) + CAST('/01/01' AS CHAR) AS SMALLDATETIME), - 1) 
                         = ANO_ANT.Data_Indicadores_Financeiros AND DIA_ATUAL.Descricao_Indicadores_Financeiros = ANO_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_03_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 2, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 2, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_03_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_03_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_06_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 5, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 5, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_06_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_06_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_12_ANT ON dbo.PROX_DIA_UTIL(CAST(CAST(YEAR(DATEADD(MONTH, - 11, DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST(MONTH(DATEADD(MONTH, - 11, 
                         DIA_ATUAL.Data_Indicadores_Financeiros)) AS CHAR) + '/' + CAST('01' AS CHAR) AS SMALLDATETIME), - 1) = MES_12_ANT.Data_Indicadores_Financeiros AND 
                         DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_12_ANT.Descricao_Indicadores_Financeiros LEFT OUTER JOIN
                         Indicadores_Financeiros AS MES_INI ON MES_INI.Data_Indicadores_Financeiros = DT_INICIO_ESTRATEGIA AND DIA_ATUAL.Descricao_Indicadores_Financeiros = MES_INI.Descricao_Indicadores_Financeiros


GO


-- =============================================
-- Funcao:   [V_ESTRATEGIA_CLIENTE_RENT]
-- Descri��o: <View que lista o rendimento da cota da carteira junto ao dos indicadores financeiros>
-- Depend�ncias:    Depende de -> dbo.ESTRATEGIA, dbo.ESTRATEGIA_CLIENTE_RENT, dbo.Cliente
--                                                          dbo.ESTRATEGIA_INDICADOR_RENT, dbo.Indicadores_Financeiros
--                                Dependem desta -> dbo.FN_ESTRATEGIA_FAT
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'V_ESTRATEGIA_CLIENTE_RENT') 
begin
       exec('DROP VIEW [dbo].[V_ESTRATEGIA_CLIENTE_RENT]')
end

GO

CREATE VIEW [dbo].[V_ESTRATEGIA_CLIENTE_RENT]
AS
SELECT     DIA_ATUAL.DT_MVTO, DIA_ATUAL.CD_BVSP, dbo.Cliente.nome_cliente, DIA_ATUAL.NR_ESTRATEGIA, dbo.ESTRATEGIA.NM_ABREV_ESTRATEGIA, 
                      DIA_ATUAL.VL_PL_ANTERIOR, DIA_ATUAL.VL_PL_DIA, DIA_ATUAL.VL_COTA_TAXA AS COTA_DIA, DIA_ATUAL.VL_RENT_TAXA AS RENT_DIA


   , A.Fator_Correcao_Indicadores_Financeiros AS FAT_CDI
, B.Fator_Correcao_Indicadores_Financeiros AS FAT_IBOV


FROM         dbo.ESTRATEGIA_CLIENTE_RENT AS DIA_ATUAL INNER JOIN
                      dbo.ESTRATEGIA ON DIA_ATUAL.NR_ESTRATEGIA = dbo.ESTRATEGIA.NR_ESTRATEGIA INNER JOIN
                      dbo.Cliente ON DIA_ATUAL.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente


INNER JOIN
                      dbo.Indicadores_Financeiros AS A ON DIA_ATUAL.DT_MVTO = A.Data_Indicadores_Financeiros AND 
                      'CDI' = A.Descricao_Indicadores_Financeiros INNER JOIN
                      dbo.Indicadores_Financeiros AS B ON DIA_ATUAL.DT_MVTO = B.Data_Indicadores_Financeiros AND 
                      'IBOVESPA' = B.Descricao_Indicadores_Financeiros


UNION
SELECT     DIA_ATUAL.DT_MVTO, DIA_ATUAL.CD_BVSP, dbo.Cliente.nome_cliente, 0 AS NR_ESTRATEGIA, DIA_ATUAL.DS_ESTRATEGIA, DIA_ATUAL.VL_PL_ANTERIOR, 
                      DIA_ATUAL.VL_PL_DIA, DIA_ATUAL.VL_COTA_TAXA AS COTA_DIA, DIA_ATUAL.VL_RENT_TAXA AS RENT_DIA


,0 AS FAT_CDI
, 0 AS FAT_IBOV


FROM         dbo.ESTRATEGIA_INDICADOR_RENT AS DIA_ATUAL INNER JOIN
                      dbo.Cliente ON DIA_ATUAL.CD_BVSP = dbo.Cliente.codigo_bvsp_cliente AND '00' = dbo.Cliente.Codigo_carteira_cliente


GO

-- =============================================
-- Funcao:   [VW_SIM_SIS_INDICE]
-- Descri��o: <View que os indicadores financeiros presentes na base do SIM>
-- Depend�ncias:    Depende de -> dbo.Indicadores_Financeiros 
--                                Dependem desta -> Vazio
-- =============================================
IF EXISTS (SELECT * FROM sysobjects WHERE name = 'VW_SIM_SIS_INDICE') 
begin
       exec('DROP VIEW [dbo].[VW_SIM_SIS_INDICE]')
end

GO

CREATE VIEW [dbo].[VW_SIM_SIS_INDICE]
AS
SELECT     Descricao_Indicadores_Financeiros AS NM_INDICE, Data_Indicadores_Financeiros AS DT_INDICE, Tipo_Indicadores_Financeiros AS TP_INDICE, NULL 
                      AS VL_VARIACAO_INDICE
FROM         dbo.indicadores_financeiros
GO




/*FUNCOES USADAS PELO SIMPLUSBOLSA */


-- =============================================
-- Objeto:   [FN_ESTRATEGIA_FAT]
-- Descri��o: <Fun��o recursiva que fornece os dados usados no gr�fico de evolu��o da estrat�gia>
-- Depend�ncias:    Depende de -> V_ESTRATEGIA_CLIENTE_RENT
--                                Dependem desta -> Vazio
-- =============================================
IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FN_ESTRATEGIA_FAT') 
begin
       exec('DROP FUNCTION [dbo].[FN_ESTRATEGIA_FAT]')
end

GO

CREATE FUNCTION [dbo].[FN_ESTRATEGIA_FAT] (@DT_INICIAL SMALLDATETIME , @DT_FINAL SMALLDATETIME , @CD_BVSP INT, @NR_ESTRATEGIA INT , @COTA_INICIAL INT)

RETURNS TABLE 

AS

RETURN 

(
WITH TABFAT (DT_MVTO,[CD_BVSP],[NR_ESTRATEGIA], DS_ESTRATEGIA,  FILHO, PAI, FAT_ESTRATEGIA , COTA_ESTRATEGIA)
AS
(
SELECT [DT_MVTO],[CD_BVSP],[NR_ESTRATEGIA] , NM_ABREV_ESTRATEGIA AS DS_ESTRATEGIA ,  filho, pai, FAT_ESTRATEGIA ,  CONVERT(DECIMAL(16,8),@COTA_INICIAL) AS COTA_ESTRATEGIA

FROM (SELECT  [DT_MVTO],[CD_BVSP] ,[NR_ESTRATEGIA], NM_ABREV_ESTRATEGIA , linha filho , linha-1 as pai, FAT_ESTRATEGIA FROM (

SELECT [DT_MVTO],[CD_BVSP],NR_ESTRATEGIA , NM_ABREV_ESTRATEGIA , ((RENT_DIA / 100)+1) AS FAT_ESTRATEGIA , ROW_NUMBER() over( partition by  [NM_ABREV_ESTRATEGIA] order by [DT_MVTO]) LINHA FROM  [V_ESTRATEGIA_CLIENTE_RENT] S
WHERE S.[CD_BVSP]  = @CD_BVSP
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND NR_ESTRATEGIA = @NR_ESTRATEGIA 
)A) S   
WHERE  PAI = 0
UNION ALL 
SELECT S.[DT_MVTO], S.[CD_BVSP], S.NR_ESTRATEGIA , S.NM_ABREV_ESTRATEGIA, S.FILHO, S.PAI, S.FAT_ESTRATEGIA,  CONVERT(DECIMAL( 16,8), S.FAT_ESTRATEGIA * B.COTA_ESTRATEGIA)
FROM (SELECT [DT_MVTO],[CD_BVSP],NR_ESTRATEGIA , NM_ABREV_ESTRATEGIA, linha filho , linha-1 as pai,  FAT_ESTRATEGIA FROM (
SELECT  [DT_MVTO],[CD_BVSP],NR_ESTRATEGIA , NM_ABREV_ESTRATEGIA, ((RENT_DIA / 100)+1) AS FAT_ESTRATEGIA, ROW_NUMBER() over(partition by  [NM_ABREV_ESTRATEGIA] order by [DT_MVTO]) LINHA FROM [V_ESTRATEGIA_CLIENTE_RENT] S
WHERE S.[CD_BVSP] = @CD_BVSP 
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND NR_ESTRATEGIA = @NR_ESTRATEGIA 

)A)S
JOIN TABFAT B
ON S.PAI = B.FILHO
)                          
SELECT * FROM TABFAT 
)


GO

-- =============================================
-- Funcao:   [FN_ESTRATEGIA_FAT_COTA]
-- Descri��o: <Fun��o recursiva que fornece os dados usados no gr�fico de evolu��o da carteira>
-- Depend�ncias:    Depende de -> dbo.ESTRATEGIA_CLIENTE_COTA_RENT
--                                Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FN_ESTRATEGIA_FAT_COTA') 
begin
       exec('DROP FUNCTION [dbo].[FN_ESTRATEGIA_FAT_COTA]')
end

GO

CREATE FUNCTION [dbo].[FN_ESTRATEGIA_FAT_COTA] (@DT_INICIAL SMALLDATETIME , @DT_FINAL SMALLDATETIME , @CD_BVSP INT, @NR_ESTRATEGIA INT , @COTA_INICIAL INT)

RETURNS TABLE 

AS

RETURN 

(
WITH TABFAT (DT_MVTO,[CD_BVSP],[NR_ESTRATEGIA], DS_ESTRATEGIA,  FILHO, PAI, FAT_ESTRATEGIA , COTA_ESTRATEGIA)
AS
(
SELECT [DT_MVTO],[CD_BVSP],[NR_ESTRATEGIA]  , NM_ABREV_ESTRATEGIA AS DS_ESTRATEGIA ,  filho, pai, cast(FAT_ESTRATEGIA as float) ,  CONVERT(DECIMAL(16,8),@COTA_INICIAL) AS COTA_ESTRATEGIA

FROM (SELECT  [DT_MVTO],[CD_BVSP] ,[NR_ESTRATEGIA], NM_ABREV_ESTRATEGIA , linha filho , linha-1 as pai, FAT_ESTRATEGIA FROM (

SELECT [DT_MVTO],[CD_BVSP],1 AS NR_ESTRATEGIA , 'CARTEIRA' AS NM_ABREV_ESTRATEGIA, ((VL_RENT_TAXA / 100)+1) AS FAT_ESTRATEGIA , ROW_NUMBER() over( partition by  'CARTEIRA' order by [DT_MVTO]) LINHA FROM  [ESTRATEGIA_CLIENTE_COTA_RENT] S
WHERE S.[CD_BVSP]  = @CD_BVSP
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND 1 = @NR_ESTRATEGIA 
)A) S   
WHERE  PAI = 0
UNION ALL 
SELECT S.[DT_MVTO], S.[CD_BVSP], S.NR_ESTRATEGIA , S.NM_ABREV_ESTRATEGIA, S.FILHO, S.PAI, cast(S.FAT_ESTRATEGIA as float),  CONVERT(DECIMAL( 16,8), S.FAT_ESTRATEGIA * B.COTA_ESTRATEGIA)
FROM (SELECT [DT_MVTO],[CD_BVSP], NR_ESTRATEGIA , NM_ABREV_ESTRATEGIA, linha filho , linha-1 as pai,  FAT_ESTRATEGIA FROM (
SELECT  [DT_MVTO],[CD_BVSP],1 AS NR_ESTRATEGIA ,  'CARTEIRA' AS NM_ABREV_ESTRATEGIA, ((VL_RENT_TAXA / 100)+1) AS FAT_ESTRATEGIA, ROW_NUMBER() over(partition by  'CARTEIRA' order by [DT_MVTO]) LINHA FROM [ESTRATEGIA_CLIENTE_COTA_RENT] S
WHERE S.[CD_BVSP] = @CD_BVSP 
AND S.[DT_MVTO] BETWEEN @DT_INICIAL AND @DT_FINAL 
AND 1 = @NR_ESTRATEGIA 

)A)S
JOIN TABFAT B
ON S.PAI = B.FILHO
)                          
SELECT * FROM TABFAT 
)

GO

-- =============================================
-- Funcao:   [FN_ESTRATEGIA_INDICADOR_FAT]
-- Descri��o: <Fun��o recursiva que fornece os dados de indicadores usados nos gr�ficos 
--                                de evolu��o da carteira e de estrat�gia>
-- Depend�ncias:    Depende de -> dbo.Indicadores_Financeiros
--                                Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FN_ESTRATEGIA_INDICADOR_FAT') 
begin
       exec('DROP FUNCTION [dbo].[FN_ESTRATEGIA_INDICADOR_FAT]')
end

GO

CREATE FUNCTION [dbo].[FN_ESTRATEGIA_INDICADOR_FAT] (@DT_INICIAL SMALLDATETIME , @DT_FINAL SMALLDATETIME , @DS_INDICADOR NVARCHAR(30) , @COTA_INICIAL INT)

RETURNS TABLE 

AS

RETURN 

(
WITH TABFAT (DT_MVTO,[DS_INDICADOR],  FILHO, PAI, FAT_INDICADOR , COTA_INDICADOR)
AS
(
SELECT [DT_MVTO],[DS_INDICADOR] ,  filho, pai, FAT_INDICADOR ,  CONVERT(DECIMAL(16,8),@COTA_INICIAL) AS COTA_INDICADOR

FROM (SELECT  [DT_MVTO] ,[DS_INDICADOR], linha filho , linha-1 as pai, FAT_INDICADOR FROM (

SELECT DATA_INDICADORES_FINANCEIROS AS [DT_MVTO], DESCRICAO_INDICADORES_FINANCEIROS AS DS_INDICADOR, FATOR_CORRECAO_INDICADORES_FINANCEIROS AS FAT_INDICADOR , ROW_NUMBER() over( partition by  DESCRICAO_INDICADORES_FINANCEIROS ORDER BY DATA_INDICADORES_FINANCEIROS) LINHA FROM  INDICADORES_FINANCEIROS S
WHERE S.DATA_INDICADORES_FINANCEIROS BETWEEN @DT_INICIAL AND @DT_FINAL 
AND DESCRICAO_INDICADORES_FINANCEIROS = @DS_INDICADOR
)A) S   
WHERE  PAI = 0
UNION ALL 
SELECT S.[DT_MVTO], S.DS_INDICADOR, S.FILHO, S.PAI, S.FAT_INDICADOR,  CONVERT(DECIMAL( 16,8), S.FAT_INDICADOR * B.COTA_INDICADOR)
FROM (SELECT [DT_MVTO],DS_INDICADOR, linha filho , linha-1 as pai,  FAT_INDICADOR FROM (
SELECT  DATA_INDICADORES_FINANCEIROS AS DT_MVTO, DESCRICAO_INDICADORES_FINANCEIROS AS DS_INDICADOR, FATOR_CORRECAO_INDICADORES_FINANCEIROS AS FAT_INDICADOR, ROW_NUMBER() over(partition by  DESCRICAO_INDICADORES_FINANCEIROS ORDER BY  DATA_INDICADORES_FINANCEIROS) LINHA FROM INDICADORES_FINANCEIROS S
WHERE S.DATA_INDICADORES_FINANCEIROS BETWEEN @DT_INICIAL AND @DT_FINAL 
AND DESCRICAO_INDICADORES_FINANCEIROS = @DS_INDICADOR 

)A)S
JOIN TABFAT B
ON S.PAI = B.FILHO
)                          
SELECT * FROM TABFAT 
)


GO

-- =============================================
-- Funcao:   [FN_PL_CARTEIRA_ESTRATEGIA]
-- Descri��o: <Fun��o que retorna os dados de composi��o de patrim�nio para Estrategia e Estrategia Cota>
-- Depend�ncias:    Depende de -> dbo.ESTRATEGIA_APLRESG_CLUBE_FUNDO, dbo.Ativo_Bvsp, dbo.Ativo_Open, dbo.ESTRATEGIA_PROVISAO_COTA
--                                dbo.Boleta_Bvsp, dbo.Boleta_Open, dbo.Carteira_Contabil, dbo.Cliente, dbo.TCCMOVTO, dbo.FN_PROX_DIA_UTIL_FEC
--                                Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'FN_PL_CARTEIRA_ESTRATEGIA') 
begin
       exec('DROP FUNCTION [dbo].[FN_PL_CARTEIRA_ESTRATEGIA]')
end

GO


CREATE FUNCTION [dbo].[FN_PL_CARTEIRA_ESTRATEGIA] (@DATA_LOCAL SMALLDATETIME , @CLIENTE_INICIAL INT , @CLIENTE_FINAL INT)
RETURNS TABLE 

AS
RETURN 
(
WITH TABCLI (
       DT_MVTO
       , CD_BVSP
       , DS_CARTEIRA
       , VL_ANTERIOR
       , VL_DIA

)
AS
(
       SELECT
       DT_MVTO
       , CD_BVSP
--     , ORDENACAO
       , DS_CARTEIRA 
       , SUM(VL_ANTERIOR) AS VL_ANTERIOR
       , SUM(VL_DIA) AS VL_DIA

       FROM
       (
       SELECT 
       DT_MVTO AS DT_MVTO
       , CD_BVSP AS CD_BVSP
       , 2 AS ORDENACAO
       , DS_PROVISAO AS DS_CARTEIRA
       , SUM(ISNULL(VL_ANTERIOR,0)) AS VL_ANTERIOR
       , SUM(ISNULL(VL_ATUAL,0)) AS VL_DIA
       FROM ESTRATEGIA_PROVISAO_COTA

       WHERE DT_MVTO = @DATA_LOCAL
       AND CD_BVSP >= @CLIENTE_INICIAL
       AND CD_BVSP <= @CLIENTE_FINAL
       GROUP BY 
       DT_MVTO 
       , CD_BVSP 
       , DS_PROVISAO

       UNION
       SELECT @DATA_LOCAL AS DT_MVTO
       , Codigo_Bvsp_Carteira_Contabil AS CD_BVSP
       , 1 AS ORDENACAO
       , TP_MERCADO AS DS_CARTEIRA
       ,
       SUM(
    CASE WHEN MERCADO = 'TER' THEN
             (ISNULL(Quantidade_Carteira_Contabil, 0) * (ISNULL(PRECO_FEC,0) - Preco_Aquisicao_Carteira_Contabil)) / ISNULL(QT_LOTE,1)
       ELSE
             ISNULL(VL_MERCADO_FEC,0)
       END)  
        AS VL_ANTERIOR
       , 0 AS VL_DIA
       FROM CARTEIRA_CONTABIL 
       WHERE
       DATA_CARTEIRA_CONTABIL = DBO.FN_PROX_DIA_UTIL_FEC(@DATA_LOCAL,-1)
       AND 
       Codigo_Bvsp_Carteira_Contabil >= @CLIENTE_INICIAL
       AND
       Codigo_Bvsp_Carteira_Contabil <= @CLIENTE_FINAL
       AND MERCADO <> 'BTC'
       AND MERCADO <> 'EMP'
       GROUP BY
       Data_Carteira_Contabil
       , Codigo_Bvsp_Carteira_Contabil
       , TP_MERCADO

       UNION
       SELECT Data_Carteira_Contabil AS DT_MVTO
       , Codigo_Bvsp_Carteira_Contabil AS CD_BVSP
       , 1 AS ORDENACAO
       , TP_MERCADO AS DS_CARTEIRA
       , 0 AS VL_ANTERIOR
       , 
       SUM(
    CASE WHEN MERCADO = 'TER' THEN
             (ISNULL(Quantidade_Carteira_Contabil, 0) * (PRECO_FEC - Preco_Aquisicao_Carteira_Contabil)) / ISNULL(QT_LOTE,1)
       ELSE
             ISNULL(VL_MERCADO_FEC,0)
       END)  
       AS VL_DIA
       FROM CARTEIRA_CONTABIL 
       WHERE
       DATA_CARTEIRA_CONTABIL = @DATA_LOCAL
       AND 
       Codigo_Bvsp_Carteira_Contabil >= @CLIENTE_INICIAL
       AND
       Codigo_Bvsp_Carteira_Contabil <= @CLIENTE_FINAL
       AND MERCADO <> 'BTC'
       AND MERCADO <> 'EMP'
       GROUP BY
       Data_Carteira_Contabil
       , Codigo_Bvsp_Carteira_Contabil
       , TP_MERCADO


       UNION
       SELECT DT_LIQUIDACAO AS DT_MVTO 
       , CODIGO_CONTA_MAE_BVSP_CLIENTE AS  CD_BVSP
       , 3 AS ORDENACAO
       , 'DEPOSITO / RETIRADA EM CONTA CORRENTE' AS DS_CARTEIRA
       , 0 AS VL_ANTERIOR
       , SUM(VL_LANCAMENTO) AS VL_DIA
       FROM TCCMOVTO INNER JOIN CLIENTE ON 
       CD_CLIENTE = codigo_bvsp_cliente
       AND '00' = Codigo_carteira_cliente
       WHERE DT_LIQUIDACAO = @DATA_LOCAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE >= @CLIENTE_INICIAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE <= @CLIENTE_FINAL 
       --AND CONTROLA_CARTEIRA_CLIENTE = 'S'
       AND ACAO_SIM = 1
       GROUP BY DT_LIQUIDACAO , CODIGO_CONTA_MAE_BVSP_CLIENTE

       UNION
       SELECT DATA_BOLETA_BVSP  AS DT_MVTO
       , CODIGO_CONTA_MAE_BVSP_CLIENTE AS  CD_BVSP 
       , 3 AS ORDENACAO
       , ' TRANSFERENCIA DE ACOES BOVESPA' AS DS_CARTEIRA 
       , 0 AS VL_ANTERIOR
       ,SUM(((Qtd_Total_Boleta_Bvsp * Preco_Boleta_Bvsp) / LOTE_ATIVO_BVSP)) 
       * 
       CASE WHEN Compra_Venda_Boleta_Bvsp = 'C' THEN  
             1
       ELSE
             -1
       END    AS VL_DIA
       
       FROM BOLETA_BVSP INNER JOIN ATIVO_BVSP ON 
       DATA_BOLETA_BVSP = DATA_ATIVO_BVSP
       AND PAPEL_BOLETA_BVSP = NOME_ATIVO_BVSP 
       INNER JOIN CLIENTE ON 
       Codigo_Bvsp_Boleta_Bvsp= codigo_bvsp_cliente
       AND '00' = Codigo_carteira_cliente
       WHERE Data_Boleta_Bvsp = @DATA_LOCAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE >= @CLIENTE_INICIAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE <= @CLIENTE_FINAL 
       --AND CONTROLA_CARTEIRA_CLIENTE = 'S'
       AND Custodia_Boleta_Bvsp = 'TRA'
       GROUP BY Data_Boleta_Bvsp, CODIGO_CONTA_MAE_BVSP_CLIENTE , Compra_Venda_Boleta_Bvsp
       
       UNION
       SELECT DATA_BOLETA_OPEN AS DT_MVTO 
       , CODIGO_CONTA_MAE_BVSP_CLIENTE AS  CD_BVSP
       , 3 AS ORDENACAO
       , 'TRANSFERENCIA TITULOS RENDA FIXA' AS DS_CARTEIRA
       , 0 AS VL_ANTERIOR
       , SUM(((Qtd_Total_Boleta_OPEN * Preco_Boleta_OPEN) * LOTE_ATIVO_OPEN)) 
       * 
       CASE WHEN Compra_Venda_Boleta_OPEN = 'C' THEN  
             1
       ELSE
             -1
       END    
       
       AS VL_DIA 

       FROM BOLETA_OPEN INNER JOIN ATIVO_OPEN ON 
       DATA_BOLETA_OPEN = DATA_ATIVO_OPEN
       AND PAPEL_BOLETA_OPEN = NOME_ATIVO_OPEN 
       INNER JOIN CLIENTE ON 
       Codigo_Bvsp_Boleta_OPEN = codigo_bvsp_cliente
       AND '00' = Codigo_carteira_cliente
       WHERE Data_Boleta_OPEN = @DATA_LOCAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE >= @CLIENTE_INICIAL
       AND CODIGO_CONTA_MAE_BVSP_CLIENTE <= @CLIENTE_FINAL 
       --AND CONTROLA_CARTEIRA_CLIENTE = 'S'
       AND Contra_Parte_Boleta_Open IN(900,902)
       GROUP BY Data_Boleta_OPEN, CODIGO_CONTA_MAE_BVSP_CLIENTE , Compra_Venda_Boleta_Open     

       UNION
       SELECT DT_MVTO 
       , CODIGO_CONTA_MAE_BVSP_CLIENTE AS CD_BVSP
       , 3 AS ORDENACAO
       , 'APLICACAO/RESGATE EM CLUBE/FUNDO' AS DS_CARTEIRA
       , 0 AS VL_ANTERIOR
       , SUM(VALOR) *-1 AS VL_DIA

       FROM ESTRATEGIA_APLRESG_CLUBE_FUNDO 
       INNER JOIN CLIENTE ON
       CD_BVSP_CLUBE_FUNDO = CODIGO_BVSP_CLIENTE
       AND '00' = CODIGO_CARTEIRA_CLIENTE
       --AND VALOR < 0
       WHERE DT_MVTO = @DATA_LOCAL
       AND codigo_Conta_Mae_Bvsp_cliente >= @CLIENTE_INICIAL
       AND codigo_Conta_Mae_Bvsp_cliente <= @CLIENTE_FINAL
       GROUP BY DT_MVTO , CODIGO_CONTA_MAE_BVSP_CLIENTE ,DT_INI , DT_FIM

       UNION
       SELECT DT_FIM  AS DT_MVTO 
       , CODIGO_CONTA_MAE_BVSP_CLIENTE AS CD_BVSP 
       , 4 AS ORDENACAO
       , 'ESTORNO APLICACAO/RESGATE EM CLUBE/FUNDO' AS DS_CARTEIRA
       , SUM(ISNULL(VALOR,0)) *-1 AS VL_ANTERIOR
       , SUM(ISNULL(VALOR,0)) *-1 AS VL_DIA
       FROM ESTRATEGIA_APLRESG_CLUBE_FUNDO 
       INNER JOIN CLIENTE ON
       CD_BVSP_CLUBE_FUNDO = CODIGO_BVSP_CLIENTE
       AND '00' = CODIGO_CARTEIRA_CLIENTE
       AND VALOR > 0
       WHERE DT_FIM >= @DATA_LOCAL
       AND DT_INI < @DATA_LOCAL
       AND codigo_Conta_Mae_Bvsp_cliente >= @CLIENTE_INICIAL
       AND codigo_Conta_Mae_Bvsp_cliente <= @CLIENTE_FINAL
       GROUP BY DT_MVTO , CODIGO_CONTA_MAE_BVSP_CLIENTE ,DT_INI , DT_FIM

       ) AS PATRIMONIO_DIA 
       GROUP BY 
         DT_MVTO
       , CD_BVSP
       , ORDENACAO
       , DS_CARTEIRA 
)                          
SELECT * FROM TABCLI 
)

GO



-- =============================================
-- Funcao:   [F_Soh_Letra]
-- Descri��o: <Fun��o que retorna a string recebida contendo apenas letras. Usada na carteira cont�bil em nome de ativos para tp_mercados espec�ficos.>
-- Depend�ncias:    Depende de -> Vazio
--                                Dependem desta -> Vazio
-- =============================================

IF EXISTS (SELECT * FROM sysobjects WHERE name = 'F_Soh_Letra') 
begin
       exec('DROP FUNCTION [dbo].[F_Soh_Letra]')
end

GO

Create Function [dbo].[F_Soh_Letra]
(
@Temp varchar(1000)
)
Returns varchar(1000)
AS
Begin
       DECLARE @PosNaoNumero SMALLINT
       SET @PosNaoNumero = PATINDEX('%[^a-z]%', @Temp)
    While @PosNaoNumero > 0
             Begin
                    Set @Temp = Stuff(@Temp, @PosNaoNumero, 1, '')
                    Set @PosNaoNumero = PATINDEX('%[^a-z]%', @Temp)
             end
    Return @Temp
End
GO


/*FLAGS DA ESTRATEGIA SIMPLUSBOLSA */

insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('listaIndicadoresGraficos', 'CDI;IBOVESPA' , 'Determina os indicadores fixos informados pela corretora, separados por ponto e v�rgula (;)', 'N')

insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('CalcDtInicialGrafico', '0',  'Determina o numero de meses usado para calcular a data inicial do gr�fico evolu��o; Para primeiro dia do ano preencher com 0 (zero)', 'N')

insert into sim_flag(Nome_Sim_Flag, Parametro_Sim_Flag, Descricao_Sim_Flag, Obrigatorio_Sim_Flag)
values('ConsultaDefaultCarteira', '1',  'Determina o valor default selecionado para a consulta de carteira cont�bil. Para mais de uma op��o, separar com  e v�rgula(;). Op��es= 0 (Estrat�gia); 1 (Cota); 2 (ClubeseFundos)', 'N')

