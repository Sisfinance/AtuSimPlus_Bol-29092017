﻿; (function () {
    var grid;
    var demo = window.demo = {};

    demo.GetGridObject = function (sender, eventArgs) {
        grid = sender;
    };

    demo.Swap = function () {
        SwapColumns($telerik.findControl(document, 'TextBox1').get_value(), $telerik.findControl(document, 'TextBox2').get_value());
    };

    function SwapColumns(index1, index2) {
        var masterTableView = grid.get_masterTableView();
        var targetUniqueName = masterTableView.get_columns()[index1].get_uniqueName();
        var sourceUniqueName = masterTableView.get_columns()[index2].get_uniqueName();
        grid.get_masterTableView().swapColumns(targetUniqueName, sourceUniqueName);
    }

    demo.Reorder = function () {
        ReorderColumns($telerik.findControl(document, 'TextBox1').get_value(), $telerik.findControl(document, 'TextBox2').get_value());
    };

    function ReorderColumns(index1, index2) {
        var masterTableView = grid.get_masterTableView();
        var targetUniqueName = masterTableView.get_columns()[index1].get_uniqueName();
        var sourceUniqueName = masterTableView.get_columns()[index2].get_uniqueName();
        grid.get_masterTableView().reorderColumns(targetUniqueName, sourceUniqueName);
    }

    demo.ResizeColumn = function (index, width) {
        var index = $telerik.findControl(document, "TextBox3").get_value();
        var width = $telerik.findControl(document, "TextBox4").get_value();
        var columnCount = grid.get_masterTableView().get_columns().length - 1;
        grid.get_masterTableView().resizeColumn(index, width);
    };

    demo.HideColumn = function (index) {
        //var index = $telerik.findControl(document, "TextBox6").get_value();
        var columnCount = grid.get_masterTableView().get_columns().length - 1;
        grid.get_masterTableView().hideColumn(index);
    };

    demo.ShowColumn = function (index) {
        //var index = $telerik.findControl(document, "TextBox6").get_value();
        var columnCount = grid.get_masterTableView().get_columns().length - 1;
        grid.get_masterTableView().showColumn(index);
    };

    demo.HideRow = function (index) {
        //var index = $telerik.findControl(document, "TextBox8").get_value();
        grid.get_masterTableView().hideItem(index);
    };

    demo.ShowRow = function () {
        var index = $telerik.findControl(document, "TextBox8").get_value();
        grid.get_masterTableView().showItem(index);
    };

    demo.ExportToExcel = function () {
        var fileName = $telerik.findControl(document, "TextBox7").get_value();
        grid.get_masterTableView().exportToExcel(fileName);
    };

    demo.ExportToWord = function () {
        var fileName = $telerik.findControl(document, "TextBox7").get_value();
        grid.get_masterTableView().exportToWord(fileName);
    };

    demo.RequestStart = function (sender, args) {
        if (args.get_eventArgument().indexOf("Export") != -1) {
            args.set_enableAjax(false);
        }
    };
})();