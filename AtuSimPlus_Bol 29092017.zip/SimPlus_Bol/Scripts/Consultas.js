﻿function $(id) {
    return document.getElementById(id);

}

function HideFiltro() {
    $('innerfiltro').style.display = "none";
}

function ShowFiltro() {
    $('innerfiltro').style.display = "block";
    document.getElementById("grid_load_filtro").style.left = ($('fieldfiltro').offsetWidth - 50) / 2 + 'px';
    document.getElementById("grid_load_filtro").style.top = ($('fieldfiltro').offsetHeight - 50) / 2 + 'px';
}

function TrocaPanels() {
    var img = $('ImgColap');
    var panelGrid = $('divGrid');
    if (img.alt == "Show Grid") {
        img.src = "Img/collapse_blue.jpg";
        img.alt = "Hide Grid";
        panelGrid.style.display = "block";
    }
    else {
        img.src = "Img/expand_blue.jpg";
        img.alt = "Show Grid";
        panelGrid.style.display = "none";
    }
}

function TrocaPanelsGenerico(idImagem, idGrid) {
    var img = $(idImagem);
    var panelGrid = $(idGrid);
    if (img.alt == "Show Grid") {
        img.src = "Img/collapse_blue.jpg";
        img.alt = "Hide Grid";
        panelGrid.style.display = "block";
    }
    else {
        img.src = "Img/expand_blue.jpg";
        img.alt = "Show Grid";
        panelGrid.style.display = "none";
    }
}

function TiraBotoesExpand(control) {
    var tabela = document.getElementById(control); //"ControlOperacaoTermoFlex_RadGrid1_ctl00");
    var element = tabela.getElementsByTagName("tr");
    for (i = 0; i < element.length; i++) {
        if (element[i].class == "rgGroupHeader" || element[i].className == "rgGroupHeader") {
            if (element[i].getElementsByTagName("input")[0] != null) {
                element[i].getElementsByTagName("input")[0].style.display = "none";
            }
        }
    }
}


