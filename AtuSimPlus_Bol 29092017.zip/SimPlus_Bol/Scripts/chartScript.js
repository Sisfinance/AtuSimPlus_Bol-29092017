﻿var FADINGTOOLTIP
var wnd_height, wnd_width;
var tooltip_height, tooltip_width;
var tooltip_shown = false;
var transparency = 100;
var timer_id = 1;
var tooltiptext;

// override events
window.onload = WindowLoading;
window.onresize = UpdateWindowSize;
document.onmousemove = AdjustToolTipPosition;

function DisplayTooltip(tooltip_text) {
    document.getElementById('txtToolTip').innerHTML = tooltip_text;
    document.getElementById('txtToolTip').style.cursor = "pointer"
            
            
            
    // FADINGTOOLTIP.innerHTML = tooltip_text;
    tooltip_shown = (tooltip_text != "") ? true : false;
    if (tooltip_text != "") {
        // Get tooltip window height
        tooltip_height = (FADINGTOOLTIP.style.pixelHeight) ? FADINGTOOLTIP.style.pixelHeight : FADINGTOOLTIP.offsetHeight;
        transparency = 0;
        ToolTipFading();
    }
    else {
        clearTimeout(timer_id);
        FADINGTOOLTIP.style.visibility = "hidden";
        document.getElementById('txtToolTip').style.visibility = "hidden"
        //document.getElementById('txtToolTip').style.visibility = "hidden"
    }
}

function AdjustToolTipPosition(e) {
    if (tooltip_shown) {
        // Depending on IE/Firefox, find out what object to use to find mouse position
        var ev;
        if (e)
            ev = e;
        else
            ev = event;
        document.getElementById('txtToolTip').style.visibility = "visible"
        FADINGTOOLTIP.style.visibility = "visible";
        console.log(e);
        FADINGTOOLTIP.style.top = e.pageY + FADINGTOOLTIP.scrollTop + 'px';
        FADINGTOOLTIP.style.left = e.pageX + 'px';

    }
}

function WindowLoading() {
    FADINGTOOLTIP = document.getElementById('floater');

    // Get tooltip  window width				
    tooltip_width = (FADINGTOOLTIP.style.pixelWidth) ? FADINGTOOLTIP.style.pixelWidth : FADINGTOOLTIP.offsetWidth;

    // Get tooltip window height
    tooltip_height = (FADINGTOOLTIP.style.pixelHeight) ? FADINGTOOLTIP.style.pixelHeight : FADINGTOOLTIP.offsetHeight;

    UpdateWindowSize();
}

function ToolTipFading() {
    if (transparency <= 100) {
        FADINGTOOLTIP.style.filter = "alpha(opacity=" + transparency + ")";
        //FADINGTOOLTIP.style.opacity=transparency/100;
        transparency += 5;
        timer_id = setTimeout('ToolTipFading()', 35);
    }
}

function UpdateWindowSize() {
    wnd_height = document.body.clientHeight;
    wnd_width = document.body.clientWidth;
}