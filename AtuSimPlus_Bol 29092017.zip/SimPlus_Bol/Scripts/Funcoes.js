﻿function confirmExcluir(strCampo, strForm) {
    if (confirm("Tem certeza que deseja realizar a exclusão?")) {
        document.forms[strForm].elements[strCampo].value = "EXCLUIR_SIM";
        document.forms[0].submit()
    }
    else {
        document.forms[strForm].elements[strCampo].value = "EXCLUIR_NAO";
        document.forms[0].submit()
    }
}
function reloadForm() {
    document.forms[0].submit();
}
function confirmDesativar(strCampo, strForm) {
    if (confirm("Tem certeza que deseja realizar a desativação?")) {
        document.forms[strForm].elements[strCampo].value = "DESATIVAR_SIM";
        document.forms[0].submit()
    }
    else {
        document.forms[strForm].elements[strCampo].value = "DESATIVAR_NAO";
        document.forms[0].submit()
    }
}

function Confirmar(campoConfirmaAcao, msg, campoAcao) {
    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        $('#' + campoConfirmaAcao).attr('value', retorno);
        $('#' + campoAcao).attr('value', "4");
        document.forms[0].submit();
    });
}

function ConfirmaCancelar(msg, page) {
    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        if (retorno) {
            window.location = page;
        }
    });
}

function ConfirmaRetornar(msg, campoConfirmaAcao) {
    //Limpa campo para evitar lixo
    $('#' + campoConfirmaAcao).attr('value', "");

    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        if (retorno) {
            $('#' + campoConfirmaAcao).attr('value', "SIM");
            document.forms[0].submit();
        }
    });

    return false;
}
 
function ConfirmaExcluir(msg, campoConfirmaAcao, blnConfirmaNao) {
    //Limpa campo para evitar lixo
    $('#' + campoConfirmaAcao).attr('value', "");

    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        if (retorno) {
            $('#' + campoConfirmaAcao).attr('value', "EXCLUIR_SIM");
            document.forms[0].submit();
        }
        else if (typeof(blnConfirmaNao) != "undefined") {
            if (blnConfirmaNao == true) {
                $('#' + campoConfirmaAcao).attr('value', "EXCLUIR_NAO");
                document.forms[0].submit();
            }
        }
    });

    return false;
}


function ConfirmaMsg(msg, campoConfirmaAcao, blnConfirmaNao) {
    //Limpa campo para evitar lixo
    $('#' + campoConfirmaAcao).attr('value', "");

    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        if (retorno) {
            $('#' + campoConfirmaAcao).attr('value', "S");
            document.forms[0].submit();
        }
        else if (typeof (blnConfirmaNao) != "undefined") {
            if (blnConfirmaNao == true) {
                $('#' + campoConfirmaAcao).attr('value', "N");
                document.forms[0].submit();
            }
        }
    });

    return false;
}

function ConfirmaInserirDados(msg, campoConfirmaAcao) {
    //Limpa campo para evitar lixo
    $('#' + campoConfirmaAcao).attr('value', "");

    jQuery.alerts.okButton = ' Sim ';
    jQuery.alerts.cancelButton = ' Não ';
    jConfirm(msg, "Confirmar", function (retorno) {
        if (retorno) {
            $('#' + campoConfirmaAcao).attr('value', "INSERIR_SIM");
            document.forms[0].submit();
        }
    });

    return false;
}

function MsgBox(msg, title, blnRedirect, page, control) {
    jAlert(msg, title, function () {
        if (blnRedirect == "true") {
            window.location = page;
        }
        else {
            //Para driblar o Telerik
            if ($('#' + control + "_0")[0]) {
                $('#' + control + "_0").focus();
            }
            else if ($('#' + control + "_text")[0]) {
                $('#' + control + "_text").focus();
            }
            else if ($('#' + control + "_dateInput_text")[0]) {
                $('#' + control + "_dateInput_text").focus();
            }
            else {
                $('#' + control).focus();
            }
        }
    });
}

function MsgBoxExitForm(msg, title) {
    jAlert(msg, title, function() {
        window.close();
    });
}

function data_mascara(controle, e) {
    var data = controle.value;
    var data_formatada;

    
    data = data.replace(/\//gi, "");

    if (data.length < 2) {
        data_formatada = data;
    }
    else if ((data.length >= 2) && (data.length < 4)) {
        data_formatada = data.substring(0, 2) + "/" + data.substring(2);
    }
    else if (data.length >= 4) {
        data_formatada = data.substring(0, 2) + "/" + data.substring(2, 4) + "/" + data.substring(4, 8);
    }

    controle.value = data_formatada;

    if (IsNumber(controle, e)) {
        return true;
    }
    else {
        return false;
    }
}

function telefone_mascara(controle, event) {
    var tel = controle.value;
    var tel_formatado;

    tel = tel.replace(/-/gi, "");

    if (IsNumber(controle, event)) { 
        if (tel.length < 4) {
            tel_formatado = tel;
        }
        else {
            tel_formatado = tel.substring(0, 4) + "-" + tel.substring(4, 8);
        }

        controle.value = tel_formatado;

        return true;
    }
    else {
        jAlert("São permitidos somente números!");
        return false;
    }
}

function Decimal(control, e, qtd_inteiros, qtd_decimais) {
    var str = control.value;
    var key;
    var keychar;
    var retorno = true;

    if (window.event) {
        key = window.event.keyCode;
    }
    else if (e) {
        key = e.which;
    }

    keychar = String.fromCharCode(key);

    //Verifica se dígito é válido
    if (("0123456789,").indexOf(keychar) > -1) {
        if ((keychar == ",") && ((str).indexOf(",") > -1)) {
            retorno = false;
        }
        else {

            retorno = true;

            var aux = str + keychar;
            var aux_split = aux.split(",");
            var inteiros = aux_split[0];
            var decimais = aux_split[1];

            //Verifica se ultrapassou limite de inteiros
            if (inteiros.length > qtd_inteiros) {
                control.value += ",";
            }
            if (typeof (decimais) != "undefined") {
                //Verifica se ultrapassou limite de decimais
                if (decimais.length > qtd_decimais) {
                    jAlert("Só são permitido " + qtd_decimais + " casas decimais.");
                    retorno = false;
                }
            }
        }
    }
    else {
        //Caso usuário tenha apertado TAB, Backspace e DEL não mostra msg (Trigger Firefox)
        if ((key != 9) && (key != 0) && (key != 8) && (key != 127)) {
            jAlert("Só são permitidos valores numericos.");
            retorno = false;
        }
    }

    if (retorno) {
        control.style.borderColor = "";
        control.style.borderStyle = "";
        return true;
    }
    else {
        control.style.border = "1px solid red";
        window.setTimeout(function () {
            control.style.borderColor = "";
            control.style.borderStyle = "";
        }, 1000);
        return false
    }
}

function IsNumber(controle, e) {
    var str = controle.value;
    var key;
    var keychar;

    if (window.event) {
        key = window.event.keyCode;
    }
    else if (e) {
        key = e.which;
    }

    keychar = String.fromCharCode(key);

    if (("0123456789").indexOf(keychar) <= -1) {
        return false;
    }
    else {
        return true;
    }
}

function IsLetter(controle, e) {
    var str = controle.value;
    var key;
    var keychar;

    if (window.event) {
        key = window.event.keyCode;
    }
    else if (e) {
        key = e.which;
    }

    keychar = String.fromCharCode(key);

    if (("ABCÇDEFGHIJKLMNOPQRSTUVXYWZ").indexOf(keychar.toUpperCase()) <= -1) {
        return false;
    }
    else {
        return true;
    }
}

function IsAlfanumeric(controle, e) {
    if (IsLetter(controle, e) || IsNumber(controle, e)) {
        return true;
    }
    else {
        return false;
    }
}

function NextFocus(controle, max, next, e) {
    var controle = document.getElementById(controle);

    if (IsNumber(controle, e)) {
        var str = controle.value.replace(/_/gi, "");
        if (str.length + 1 == max) {

            var key;
            var keychar;

            if (window.event) {
                key = window.event.keyCode;
            }
            else if (e) {
                key = e.which;
            }

            keychar = String.fromCharCode(key);

            controle.value += keychar;
            document.getElementById(next).focus();

            return false;
        }

        return true;
    }
    else {
        return false;
    }
}

function ExpandirDIV(dvnome) {
    if ($(dvnome).is(':hidden')) {
        $(dvnome).slideToggle("slow");
        $(this).toggleClass("active");
    }
}

function MostrarDIV(dvnome) {
    $(dvnome).show();
}

function ComprimirDIV(dvnome) {
    $(dvnome).slideUp();

}

function OcultarDIV(dvnome) {
    $(dvnome).hide();
}

function FormSubmitAguarde() {
    oPopup = window.createPopup();
    var oPopupBody = oPopup.document.body;
    oPopupBody.innerHTML = "<font face='arial' size='2'>&nbsp;&nbsp;<img src='~/Img/loading.gif' border='0'>&nbsp;&nbsp; Por favor aguarde...</font>";
    oPopup.show(window.document.body.clientWidth / 2 - 100, window.document.body.clientHeight / 2 - 0, 250, 100, document.body);
}

var dhtmlgoodies_tooltip = false;
var dhtmlgoodies_tooltipShadow = false;
var dhtmlgoodies_shadowSize = 4;
var dhtmlgoodies_tooltipMaxWidth = 200;
var dhtmlgoodies_tooltipMinWidth = 100;
var dhtmlgoodies_iframe = false;
var tooltip_is_msie = (navigator.userAgent.indexOf('MSIE') >= 0 && navigator.userAgent.indexOf('opera') == -1 && document.all) ? true : false;
	

function enableTooltip(e, tooltipTxt) {

    var bodyWidth = Math.max(document.body.clientWidth, document.documentElement.clientWidth) - 20;

    if (!dhtmlgoodies_tooltip) {
        dhtmlgoodies_tooltip = document.createElement('DIV');
        dhtmlgoodies_tooltip.id = 'dhtmlgoodies_tooltip';
        dhtmlgoodies_tooltipShadow = document.createElement('DIV');
        dhtmlgoodies_tooltipShadow.id = 'dhtmlgoodies_tooltipShadow';

        document.body.appendChild(dhtmlgoodies_tooltip);
        document.body.appendChild(dhtmlgoodies_tooltipShadow);

        if (tooltip_is_msie) {
            dhtmlgoodies_iframe = document.createElement('IFRAME');
            dhtmlgoodies_iframe.frameborder = '5';
            dhtmlgoodies_iframe.style.backgroundColor = '#FFFFFF';
            dhtmlgoodies_iframe.src = '#';
            dhtmlgoodies_iframe.style.zIndex = 100;
            dhtmlgoodies_iframe.style.position = 'absolute';
            document.body.appendChild(dhtmlgoodies_iframe);
        }

    }

    dhtmlgoodies_tooltip.style.display = 'block';
    dhtmlgoodies_tooltipShadow.style.display = 'block';
    if (tooltip_is_msie) dhtmlgoodies_iframe.style.display = 'block';

    var st = Math.max(document.body.scrollTop, document.documentElement.scrollTop);
    if (navigator.userAgent.toLowerCase().indexOf('safari') >= 0) st = 0;
    var leftPos = e.clientX + 10;

    dhtmlgoodies_tooltip.style.width = null; // Reset style width if it's set 
    dhtmlgoodies_tooltip.innerHTML = tooltipTxt;
    dhtmlgoodies_tooltip.style.left = leftPos + 'px';
    dhtmlgoodies_tooltip.style.top = e.clientY + 10 + st + 'px';


    dhtmlgoodies_tooltipShadow.style.left = leftPos + dhtmlgoodies_shadowSize + 'px';
    dhtmlgoodies_tooltipShadow.style.top = e.clientY + 10 + st + dhtmlgoodies_shadowSize + 'px';

    if (dhtmlgoodies_tooltip.offsetWidth > dhtmlgoodies_tooltipMaxWidth) {	/* Exceeding max width of tooltip ? */
        dhtmlgoodies_tooltip.style.width = dhtmlgoodies_tooltipMaxWidth + 'px';
    }

    var tooltipWidth = dhtmlgoodies_tooltip.offsetWidth;
    if (tooltipWidth < dhtmlgoodies_tooltipMinWidth) tooltipWidth = dhtmlgoodies_tooltipMinWidth;


    dhtmlgoodies_tooltip.style.width = tooltipWidth + 'px';
    dhtmlgoodies_tooltipShadow.style.width = dhtmlgoodies_tooltip.offsetWidth + 'px';
    dhtmlgoodies_tooltipShadow.style.height = dhtmlgoodies_tooltip.offsetHeight + 'px';

    if ((leftPos + tooltipWidth) > bodyWidth) {
        dhtmlgoodies_tooltip.style.left = (dhtmlgoodies_tooltipShadow.style.left.replace('px', '') - ((leftPos + tooltipWidth) - bodyWidth)) + 'px';
        dhtmlgoodies_tooltipShadow.style.left = (dhtmlgoodies_tooltipShadow.style.left.replace('px', '') - ((leftPos + tooltipWidth) - bodyWidth) + dhtmlgoodies_shadowSize) + 'px';
    }

    if (tooltip_is_msie) {
        dhtmlgoodies_iframe.style.left = dhtmlgoodies_tooltip.style.left;
        dhtmlgoodies_iframe.style.top = dhtmlgoodies_tooltip.style.top;
        dhtmlgoodies_iframe.style.width = dhtmlgoodies_tooltip.offsetWidth + 'px';
        dhtmlgoodies_iframe.style.height = dhtmlgoodies_tooltip.offsetHeight + 'px';

    }

}

function disableTooltip() {
    dhtmlgoodies_tooltip.style.display = 'none';
    dhtmlgoodies_tooltipShadow.style.display = 'none';
    if (tooltip_is_msie) dhtmlgoodies_iframe.style.display = 'none';
}
	
function mostradvCarregando(nmDiv) {
    var dv = document.getElementsByClassName(nmDiv)[0];
    dv.style.visibility = 'visible';
    setTimeout(function ()
    { dv.style.visibility = 'hidden'; }, 30000);
}